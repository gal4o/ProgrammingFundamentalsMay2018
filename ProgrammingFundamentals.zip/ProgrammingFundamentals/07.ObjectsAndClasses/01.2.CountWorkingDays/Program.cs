﻿using System;

namespace _01._2.CountWorkingDays
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
